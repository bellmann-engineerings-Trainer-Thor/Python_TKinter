from meinEigenesTk import MeinEigensTk

app = MeinEigensTk()
app.mainloop()